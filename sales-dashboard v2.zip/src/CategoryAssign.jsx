import { formatRupiah, formatNumber } from './parseData'

export const CATEGORY_OPTIONS = ['Online Underwear', 'Online Sport']
export const UNCATEGORIZED = 'Tidak dikategorikan'

export default function CategoryAssign({ data, categories, onChange }) {
  const total = data.rankedCustomers.length
  const assignedCount = data.rankedCustomers.filter((c) => categories[c]).length

  return (
    <div className="table-block">
      <div className="table-block-header">
        <h3 className="block-title">Tandai kategori pelanggan penagihan</h3>
        <span className="assign-progress">
          {assignedCount} / {total} sudah ditandai
        </span>
      </div>
      <p className="assign-hint">
        Pilih kategori untuk masing-masing pelanggan penagihan. Yang belum dipilih akan dianggap{' '}
        <em>{UNCATEGORIZED.toLowerCase()}</em> dan tidak masuk ringkasan kategori di bawah.
      </p>
      <div className="table-scroll">
        <table className="data-table">
          <thead>
            <tr>
              <th>Pelanggan penagihan</th>
              <th className="num">Total omset</th>
              <th className="num">Total order</th>
              <th>Kategori</th>
            </tr>
          </thead>
          <tbody>
            {data.rankedCustomers.map((c) => (
              <tr key={c}>
                <td>{c}</td>
                <td className="num mono">{formatRupiah(data.customerTotals[c])}</td>
                <td className="num mono">{formatNumber(data.customerCounts[c])}</td>
                <td>
                  <select
                    className="category-select"
                    value={categories[c] || ''}
                    onChange={(e) => onChange(c, e.target.value)}
                  >
                    <option value="">{UNCATEGORIZED}</option>
                    {CATEGORY_OPTIONS.map((opt) => (
                      <option key={opt} value={opt}>
                        {opt}
                      </option>
                    ))}
                  </select>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
